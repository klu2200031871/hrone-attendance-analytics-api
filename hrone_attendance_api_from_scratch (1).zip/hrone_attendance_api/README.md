# Employee Attendance & Analytics API

A Python/FastAPI/MongoDB implementation of employee punch-in/out, manual corrections with audit history, and analytics using MongoDB aggregation pipelines.

## Requirements
- Python 3.11+
- MongoDB 6.0+ (local or MongoDB Atlas)
- Git

## Setup (Windows PowerShell)
```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set `MONGODB_URI` to your MongoDB connection string. Never commit `.env`.

## Run
```powershell
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs for interactive API documentation.

## Endpoints
- `GET /health` — database health check
- `POST /attendance/punch-in` — create an attendance record
- `POST /attendance/punch-out` — complete an open record
- `GET /attendance` — list attendance with optional filters
- `PATCH /attendance/{attendance_id}/correction` — manual correction with audit entry
- `GET /attendance/{attendance_id}/audit` — read audit history
- `GET /analytics/employee/{employee_id}` — employee totals via aggregation
- `GET /analytics/daily` — daily attendance totals via aggregation

### Example punch-in
```json
{
  "employee_id": "EMP001"
}
```

### Example punch-out
```json
{
  "employee_id": "EMP001"
}
```

## Important notes
This is a from-scratch baseline because the official assignment kit/API contract was not supplied to this workspace. Before submitting, compare endpoint names, JSON fields, business rules, status codes, and aggregation output with the official contract. Run tests against the provided sample data and add any missing requirements. The implementation is a learning starting point and should be understood and reviewed by the candidate.
