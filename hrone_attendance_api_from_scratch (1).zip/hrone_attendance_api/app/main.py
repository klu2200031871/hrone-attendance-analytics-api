"""Employee Attendance & Analytics API - starter implementation.

Run:
  pip install -r requirements.txt
  uvicorn app.main:app --reload

Set MONGODB_URI and MONGODB_DATABASE in .env for MongoDB.
This project intentionally keeps business rules straightforward; confirm the
official assignment contract and adapt endpoint names/fields as needed.
"""
import os
from datetime import datetime, timezone, date
from typing import Optional, Any

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from pymongo import MongoClient, ReturnDocument
from pymongo.errors import PyMongoError

load_dotenv()

app = FastAPI(
    title="Employee Attendance & Analytics API",
    version="1.0.0",
    description="Attendance punch-in/out, audited manual corrections, and analytics.",
)

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DATABASE = os.getenv("MONGODB_DATABASE", "hrone_attendance")
client: Optional[MongoClient] = None
db: Any = None

def get_db():
    """Connect lazily so the app can start even if MongoDB is temporarily down."""
    global client, db
    if db is None:
        try:
            client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=3000)
            client.admin.command("ping")
            db = client[MONGODB_DATABASE]
            db.attendance.create_index([("employee_id", 1), ("work_date", 1)], unique=True)
            db.audit_logs.create_index([("attendance_id", 1), ("changed_at", -1)])
        except PyMongoError as exc:
            if client:
                client.close()
            client = None
            db = None
            raise HTTPException(status_code=503, detail="MongoDB is unavailable. Check MONGODB_URI.") from exc
    return db

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def work_date_for(value: datetime) -> str:
    return value.date().isoformat()

def serialize(document: dict) -> dict:
    if not document:
        return document
    result = dict(document)
    result.pop("_id", None)
    for key, value in list(result.items()):
        if isinstance(value, datetime):
            result[key] = value.isoformat()
    return result

class PunchInRequest(BaseModel):
    employee_id: str = Field(min_length=1, max_length=100)
    punched_at: Optional[datetime] = None

class PunchOutRequest(BaseModel):
    employee_id: str = Field(min_length=1, max_length=100)
    punched_at: Optional[datetime] = None

class CorrectionRequest(BaseModel):
    corrected_by: str = Field(min_length=1, max_length=100)
    reason: str = Field(min_length=3, max_length=1000)
    punch_in: Optional[datetime] = None
    punch_out: Optional[datetime] = None

@app.get("/health")
def health():
    try:
        get_db().command("ping")
        return {"status": "ok", "database": "connected"}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=503, detail="Service unavailable")

@app.post("/attendance/punch-in", status_code=201)
def punch_in(request: PunchInRequest):
    database = get_db()
    now = request.punched_at or utc_now()
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    day = work_date_for(now)
    existing = database.attendance.find_one({"employee_id": request.employee_id, "work_date": day})
    if existing and existing.get("punch_in") and not existing.get("punch_out"):
        raise HTTPException(status_code=409, detail="Employee has already punched in and not punched out.")
    if existing and existing.get("punch_in") and existing.get("punch_out"):
        raise HTTPException(status_code=409, detail="Attendance already completed for this work date.")
    document = {
        "employee_id": request.employee_id,
        "work_date": day,
        "punch_in": now,
        "punch_out": None,
        "status": "open",
        "created_at": utc_now(),
        "updated_at": utc_now(),
    }
    try:
        database.attendance.insert_one(document)
    except PyMongoError as exc:
        # The unique index also protects against concurrent duplicate requests.
        raise HTTPException(status_code=409, detail="Attendance already exists for this employee and date.") from exc
    return serialize(document)

@app.post("/attendance/punch-out")
def punch_out(request: PunchOutRequest):
    database = get_db()
    now = request.punched_at or utc_now()
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    day = work_date_for(now)
    record = database.attendance.find_one({
        "employee_id": request.employee_id,
        "work_date": day,
        "punch_in": {"$ne": None},
        "punch_out": None,
    })
    if not record:
        raise HTTPException(status_code=404, detail="No open attendance record found for this employee and date.")
    if now < record["punch_in"]:
        raise HTTPException(status_code=400, detail="Punch-out cannot be earlier than punch-in.")
    updated = database.attendance.find_one_and_update(
        {"_id": record["_id"], "punch_out": None},
        {"$set": {"punch_out": now, "status": "completed", "updated_at": utc_now()}},
        return_document=ReturnDocument.AFTER,
    )
    if not updated:
        raise HTTPException(status_code=409, detail="Attendance was updated by another request.")
    return serialize(updated)

@app.patch("/attendance/{attendance_id}/correction")
def correct_attendance(attendance_id: str, request: CorrectionRequest):
    database = get_db()
    from bson import ObjectId
    if not ObjectId.is_valid(attendance_id):
        raise HTTPException(status_code=400, detail="Invalid attendance_id.")
    record = database.attendance.find_one({"_id": ObjectId(attendance_id)})
    if not record:
        raise HTTPException(status_code=404, detail="Attendance record not found.")
    changes = {}
    if request.punch_in is not None:
        new_in = request.punch_in
        if new_in.tzinfo is None:
            new_in = new_in.replace(tzinfo=timezone.utc)
        changes["punch_in"] = new_in
    else:
        new_in = record.get("punch_in")
    if request.punch_out is not None:
        new_out = request.punch_out
        if new_out.tzinfo is None:
            new_out = new_out.replace(tzinfo=timezone.utc)
        changes["punch_out"] = new_out
    else:
        new_out = record.get("punch_out")
    if new_in and new_out and new_out < new_in:
        raise HTTPException(status_code=400, detail="Punch-out cannot be earlier than punch-in.")
    if not changes:
        raise HTTPException(status_code=400, detail="Provide punch_in and/or punch_out to correct.")
    before = {key: record.get(key) for key in changes}
    changes["status"] = "completed" if new_out else "open"
    changes["updated_at"] = utc_now()
    database.attendance.update_one({"_id": record["_id"]}, {"$set": changes})
    audit = {
        "attendance_id": str(record["_id"]),
        "employee_id": record["employee_id"],
        "corrected_by": request.corrected_by,
        "reason": request.reason,
        "before": before,
        "after": {key: changes[key] for key in before},
        "changed_at": utc_now(),
    }
    database.audit_logs.insert_one(audit)
    updated = database.attendance.find_one({"_id": record["_id"]})
    result = serialize(updated)
    result["attendance_id"] = str(record["_id"])
    return result

@app.get("/attendance/{attendance_id}/audit")
def attendance_audit(attendance_id: str):
    from bson import ObjectId
    if not ObjectId.is_valid(attendance_id):
        raise HTTPException(status_code=400, detail="Invalid attendance_id.")
    database = get_db()
    rows = database.audit_logs.find({"attendance_id": attendance_id}).sort("changed_at", -1)
    return {"items": [serialize(row) for row in rows]}

@app.get("/analytics/employee/{employee_id}")
def employee_analytics(
    employee_id: str,
    start_date: Optional[date] = Query(default=None),
    end_date: Optional[date] = Query(default=None),
):
    database = get_db()
    match = {"employee_id": employee_id}
    if start_date or end_date:
        date_filter = {}
        if start_date:
            date_filter["$gte"] = start_date.isoformat()
        if end_date:
            date_filter["$lte"] = end_date.isoformat()
        match["work_date"] = date_filter
    pipeline = [
        {"$match": match},
        {"$group": {
            "_id": "$employee_id",
            "days": {"$sum": 1},
            "completed_days": {"$sum": {"$cond": [{"$eq": ["$status", "completed"]}, 1, 0]}},
            "open_days": {"$sum": {"$cond": [{"$eq": ["$status", "open"]}, 1, 0]}},
            "total_minutes": {"$sum": {"$cond": [
                {"$and": [{"$ne": ["$punch_in", None]}, {"$ne": ["$punch_out", None]}]},
                {"$divide": [{"$subtract": ["$punch_out", "$punch_in"]}, 60000]},
                0
            ]}},
        }},
        {"$project": {
            "_id": 0, "employee_id": "$_id", "days": 1,
            "completed_days": 1, "open_days": 1,
            "total_minutes": {"$round": ["$total_minutes", 2]},
        }},
    ]
    results = list(database.attendance.aggregate(pipeline))
    return results[0] if results else {
        "employee_id": employee_id, "days": 0, "completed_days": 0,
        "open_days": 0, "total_minutes": 0
    }

@app.get("/analytics/daily")
def daily_analytics(
    start_date: Optional[date] = Query(default=None),
    end_date: Optional[date] = Query(default=None),
):
    database = get_db()
    match = {}
    date_filter = {}
    if start_date:
        date_filter["$gte"] = start_date.isoformat()
    if end_date:
        date_filter["$lte"] = end_date.isoformat()
    if date_filter:
        match["work_date"] = date_filter
    pipeline = [
        {"$match": match},
        {"$group": {
            "_id": "$work_date",
            "employees": {"$addToSet": "$employee_id"},
            "total_records": {"$sum": 1},
            "completed": {"$sum": {"$cond": [{"$eq": ["$status", "completed"]}, 1, 0]}},
            "open": {"$sum": {"$cond": [{"$eq": ["$status", "open"]}, 1, 0]}},
        }},
        {"$project": {
            "_id": 0, "work_date": "$_id",
            "employee_count": {"$size": "$employees"},
            "total_records": 1, "completed": 1, "open": 1,
        }},
        {"$sort": {"work_date": 1}},
    ]
    return {"items": list(database.attendance.aggregate(pipeline))}

@app.get("/attendance")
def list_attendance(
    employee_id: Optional[str] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    limit: int = Query(default=100, ge=1, le=500),
):
    database = get_db()
    match = {}
    if employee_id:
        match["employee_id"] = employee_id
    date_filter = {}
    if start_date:
        date_filter["$gte"] = start_date.isoformat()
    if end_date:
        date_filter["$lte"] = end_date.isoformat()
    if date_filter:
        match["work_date"] = date_filter
    rows = database.attendance.find(match).sort("work_date", -1).limit(limit)
    result = []
    for row in rows:
        item = serialize(row)
        item["attendance_id"] = str(row["_id"])
        result.append(item)
    return {"items": result}
