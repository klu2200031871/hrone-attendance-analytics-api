# Design Decisions

## 1. FastAPI
FastAPI provides request validation through Pydantic models and automatically generates OpenAPI documentation, making endpoints easy to inspect and test.

## 2. MongoDB and PyMongo
PyMongo is used directly to make collection operations and aggregation pipelines explicit. The database URI and database name are environment-configurable.

## 3. Attendance data
Each attendance document represents one employee's record for one work date, with punch-in, optional punch-out, status, and timestamps. A compound unique index is intended to prevent duplicate employee/date records.

## 4. Manual corrections
Corrections require an actor and reason. An audit document captures the affected attendance ID and before/after values. For a production-grade system, use a MongoDB transaction where supported so the update and audit insert succeed or fail together.

## 5. Analytics
Employee and daily analytics use MongoDB `$match`, `$group`, and `$project` stages rather than loading all records into Python. This keeps the aggregation work in the database.

## 6. Time handling
API timestamps are stored as timezone-aware UTC datetimes when clients omit a timezone. The official assignment may require a specific business timezone; align date boundaries with that contract before final submission.

## 7. Scope and assumptions
This baseline was built from scratch without the official problem statement, OpenAPI contract, or sample data. Therefore endpoint names, response shapes, time-zone rules, correction permissions, and all business rules must be verified against the supplied kit.
